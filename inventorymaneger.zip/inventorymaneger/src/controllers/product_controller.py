from flask import jsonify, request
from models.product_model import ProductModel

class ProductController:
    def __init__(self, mysql):
        self.product_model = ProductModel(mysql)

    def list_product(self):
        try:
            productos = self.product_model.listar_productos()
            return jsonify({'productos': productos, 'mensaje': "Productos listado."})
        except Exception as ex:
            return jsonify({'mensaje': "Error"}), 500