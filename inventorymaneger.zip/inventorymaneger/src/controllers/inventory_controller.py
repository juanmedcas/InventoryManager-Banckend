from flask import jsonify, request
from models.inventory_model import InventoryModel

class InventoryController:
    def __init__(self, mysql):
        self.inventory_model = InventoryModel(mysql)

    def list_inventory(self):
        try:
            inventarios = self.inventory_model.listar_inventarios()
            return jsonify({'inventarios': inventarios, 'mensaje': "Inventario listado."})
        except Exception as ex:
            return jsonify({'mensaje': "Error"}), 500

    def list_inventory_id(self, id):
        try:
            inventory = self.inventory_model.listar_inventario_id(id)
            if inventory:
                return jsonify({'inventarios': inventory, 'mensaje': "Producto Listado."})
            else:
                return jsonify({'mensaje': "Inventario no encontrado."}), 404
        except Exception as ex:
            return jsonify({'mensaje': "Error"}), 500
        
    def update_inventory(self, id):
        print(id)
        try:
            self.inventory_model.actualizar_inventario(id)
            return jsonify({'mensaje': "Producto Actualizado."})
        except Exception as ex:
            return jsonify({'mensaje': "Error"}), 500

    def create_inventory(self, data):
        try:
            # Extrae los datos del diccionario proporcionado
            id = data.get('id')
            quantity = data.get('quantity')
            serial_number = data.get('serial_number')
            name = data.get('name')
            status = data.get('status', 'Entregar')  # Valor por defecto
            product_id = data.get('product_id')
            user_id = data.get('user_id')
            date = data.get('date')

            # Llama al método del modelo para crear el inventario
            self.inventory_model.crear_inventario(id, quantity, serial_number, name, status, product_id, user_id, date)
            return {'mensaje': "Inventario registrado con éxito!"}, 201
        except Exception as ex:
            return {'mensaje': "Error", 'error': str(ex)}, 500
