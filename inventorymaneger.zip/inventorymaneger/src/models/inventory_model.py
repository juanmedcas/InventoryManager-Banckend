class InventoryModel:
    def __init__(self, mysql):
        self.mysql = mysql

    def listar_inventarios(self):
        cursor = self.mysql.connection.cursor()
        #cursor=conexion.connection.cursor()
        sql = "SELECT * FROM `inventory`"
        cursor.execute(sql)
        datos = cursor.fetchall()
        inventarios = [{'id': fila[0], 'quantity': fila[1], 'serial_number': fila[2], 'name': fila[3], 'status': fila[4], 'date': fila[7]} for fila in datos]
        return inventarios

    def listar_inventario_id(self, id):
        print(id)
        cursor = self.mysql.connection.cursor()
        sql="SELECT * FROM `inventory` WHERE id = '{0}'".format(id)
        cursor.execute(sql)
        datos = cursor.fetchone()
        return {'id': datos[0], 'name': datos[3], 'status': datos[4]} if datos else None
    
    def actualizar_inventario(self, id):
        cursor = self.mysql.connection.cursor()
        sql="UPDATE `inventory` SET `status`= 'Entregado' WHERE `id`='{0}' ".format(id)
        cursor.execute(sql)
        self.mysql.connection.commit()

    def crear_inventario(self, id, quantity, serial_number, name, status, product_id, user_id, date):
        cursor = self.mysql.connection.cursor()
        sql = """
        INSERT INTO `inventory` (`id`, `quantity`, `serial_number`, `name`, `status`, `product_id`, `user_id`, `date`)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(sql, (id, quantity, serial_number, name, status, product_id, user_id, date))
        self.mysql.connection.commit()
    
