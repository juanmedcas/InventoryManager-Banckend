class ProductModel:
    def __init__(self, mysql):
        self.mysql = mysql

    def listar_productos(self):
        cursor = self.mysql.connection.cursor()
        #cursor=conexion.connection.cursor()
        sql = "SELECT * FROM `product`"
        cursor.execute(sql)
        datos = cursor.fetchall()
        productos = [{'id': fila[0], 'name': fila[1], 'description': fila[2]} for fila in datos]
        return productos