import MySQLdb
from flask import Flask, jsonify, request
from config import config
from flask_mysqldb import MySQL
from controllers.inventory_controller import InventoryController
from controllers.product_controller import ProductController
from flask_cors import CORS

app=Flask(__name__)

# Configuración de la base de datos
app.config.from_object(config['development'])
conexion = MySQL(app)

# Configuración de CORS
CORS(app, origins="http://localhost:4200")  # Ajustar

# Inicialización del controladores
inventory_controller = InventoryController(conexion)
product_controller = ProductController(conexion)

"""@app.route('/')
def index():
    return "Este es mi Backend en python" """

# Rutas
@app.route('/inventory')
def listar_inventorio():
    return inventory_controller.list_inventory()

@app.route('/inventory/<id>', methods=['GET'])
def listar_inventario_id(id):
    return inventory_controller.list_inventory_id(id)

@app.route('/inventory/<id>', methods=['PUT'])
def actualizar_inventario(id):
    return inventory_controller.update_inventory(id)

@app.route('/inventory', methods=['POST'])
def crear_inventario():
    data = request.json 
    print(data)
    #if not all([data.get('id'), data.get('quantity'), data.get('serial_number'), data.get('name'), data.get('product_id'), data.get('user_id'), data.get('date')]):
        #return jsonify({'mensaje': "Faltan datos necesarios"}), 400

    try:
        response, status_code = inventory_controller.create_inventory(data)
        return jsonify(response), status_code
    except Exception as e:
        return jsonify({'mensaje': "Error", 'error': str(e)}), 500

@app.route('/product')
def listar_productos():
    return product_controller.list_product()
    
@app.route('/users')
def listar_usuarios():
    try:
        cursor=conexion.connection.cursor()
        sql="SELECT * FROM `user`"
        cursor.execute(sql)
        datos=cursor.fetchall()
        usuarios=[]
        for fila in datos:
            usuario={'id':fila[0], 'username':fila[1]}
            usuarios.append(usuario)
        """print(datos)"""
        return jsonify({'usuarios': usuarios, 'mensaje': "Usuarios listados."})
        """return "Ok" """
    except Exception as ex:
        return jsonify({'mensaje': "Error"})
    
@app.route('/users/<codigo>', methods=['GET'])
def listar_usuario(codigo):
    try:
        cursor=conexion.connection.cursor()
        sql="SELECT * FROM `user` WHERE id = '{0}'".format(codigo)
        cursor.execute(sql)
        datos=cursor.fetchone()
        if datos != None:
            usuario={'id':datos[0], 'username':datos[1]}
            return jsonify({'usuarios': usuario, 'mensaje': "Usuario listado."})
        else:
            return jsonify({'mensaje': "Usuario no encontrado."})
    except Exception as ex:
        return jsonify({'mensaje': "Error"})

@app.route('/user', methods=['POST'])
def registrar_usuario():
    try: 
        #print(request.json)
        cursor=conexion.connection.cursor()
        sql = """INSERT INTO `user`(`id`, `username`) 
                    VALUES ('{0}','{1}')""".format(request.json['id'],request.json['username'])
        cursor.execute(sql)
        conexion.connection.commit()
        return jsonify({'mensaje': "Usuario registrado con exito!"})
    except Exception as ex:
        return jsonify({'mensaje': "Error"})
    
@app.route('/user/<codigo>', methods=['PUT'])
def actualizar_usuario(codigo):
    try:
        cursor=conexion.connection.cursor()
        sql="""UPDATE `user` SET `username`= '{0}' WHERE `id`='{1}' """.format(request.json['username'],codigo)
        cursor.execute(sql)
        conexion.connection.commit()
        return jsonify({'mensaje': "Usuario Actualizado."})
    except Exception as ex:
        return jsonify({'mensaje': "Error"})
    
@app.route('/user/<codigo>', methods=['DELETE'])
def eliminar_usuario(codigo):
    try: 
        cursor=conexion.connection.cursor()
        sql = "DELETE FROM `user` WHERE `id` = '{0}' ".format(codigo)
        cursor.execute(sql)
        conexion.connection.commit()
        return jsonify({'mensaje': "Usuario Eliminado con exito!"})
    except Exception as ex:
        return jsonify({'mensaje': "Error"})
    
def pagina_no_encontrada(error):
    return "<h1>La página que intentas buscar no existe ... :(</h1>", 404

if __name__ == '__main__':
    #app.config.from_object(config['development'])
    app.register_error_handler(404, pagina_no_encontrada)
    """app.run(debug=True)"""
    app.run()